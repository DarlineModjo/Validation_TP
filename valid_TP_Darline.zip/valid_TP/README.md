Création de l'applicatiion bot

Install discord.py:

    $ pip install -U discord.py

Install shodan:

    $ pip install shodan

Run command: 

    $ python botIPValid.py

Notes :
Je commence par connecter mon bot au serveur 
J'importer discord 
Je connecte le client à mon bot ensuite 
je mets mon bot en ligne  puis j'important mon Token dans le script